// Auto-generated. Do not edit!

// (in-package pcm_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Vector = require('./Vector.js');
let Point = require('./Point.js');

//-----------------------------------------------------------

class Plane {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.frame_id = null;
      this.width = null;
      this.height = null;
      this.angle_x = null;
      this.angle_y = null;
      this.angle_z = null;
      this.equ_a = null;
      this.equ_b = null;
      this.equ_c = null;
      this.equ_d = null;
      this.vec_x = null;
      this.vec_y = null;
      this.vec_z = null;
      this.mean_center = null;
      this.median_center = null;
      this.size_center = null;
      this.octagon_points = null;
    }
    else {
      if (initObj.hasOwnProperty('frame_id')) {
        this.frame_id = initObj.frame_id
      }
      else {
        this.frame_id = '';
      }
      if (initObj.hasOwnProperty('width')) {
        this.width = initObj.width
      }
      else {
        this.width = 0.0;
      }
      if (initObj.hasOwnProperty('height')) {
        this.height = initObj.height
      }
      else {
        this.height = 0.0;
      }
      if (initObj.hasOwnProperty('angle_x')) {
        this.angle_x = initObj.angle_x
      }
      else {
        this.angle_x = 0.0;
      }
      if (initObj.hasOwnProperty('angle_y')) {
        this.angle_y = initObj.angle_y
      }
      else {
        this.angle_y = 0.0;
      }
      if (initObj.hasOwnProperty('angle_z')) {
        this.angle_z = initObj.angle_z
      }
      else {
        this.angle_z = 0.0;
      }
      if (initObj.hasOwnProperty('equ_a')) {
        this.equ_a = initObj.equ_a
      }
      else {
        this.equ_a = 0.0;
      }
      if (initObj.hasOwnProperty('equ_b')) {
        this.equ_b = initObj.equ_b
      }
      else {
        this.equ_b = 0.0;
      }
      if (initObj.hasOwnProperty('equ_c')) {
        this.equ_c = initObj.equ_c
      }
      else {
        this.equ_c = 0.0;
      }
      if (initObj.hasOwnProperty('equ_d')) {
        this.equ_d = initObj.equ_d
      }
      else {
        this.equ_d = 0.0;
      }
      if (initObj.hasOwnProperty('vec_x')) {
        this.vec_x = initObj.vec_x
      }
      else {
        this.vec_x = new Vector();
      }
      if (initObj.hasOwnProperty('vec_y')) {
        this.vec_y = initObj.vec_y
      }
      else {
        this.vec_y = new Vector();
      }
      if (initObj.hasOwnProperty('vec_z')) {
        this.vec_z = initObj.vec_z
      }
      else {
        this.vec_z = new Vector();
      }
      if (initObj.hasOwnProperty('mean_center')) {
        this.mean_center = initObj.mean_center
      }
      else {
        this.mean_center = new Point();
      }
      if (initObj.hasOwnProperty('median_center')) {
        this.median_center = initObj.median_center
      }
      else {
        this.median_center = new Point();
      }
      if (initObj.hasOwnProperty('size_center')) {
        this.size_center = initObj.size_center
      }
      else {
        this.size_center = new Point();
      }
      if (initObj.hasOwnProperty('octagon_points')) {
        this.octagon_points = initObj.octagon_points
      }
      else {
        this.octagon_points = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Plane
    // Serialize message field [frame_id]
    bufferOffset = _serializer.string(obj.frame_id, buffer, bufferOffset);
    // Serialize message field [width]
    bufferOffset = _serializer.float32(obj.width, buffer, bufferOffset);
    // Serialize message field [height]
    bufferOffset = _serializer.float32(obj.height, buffer, bufferOffset);
    // Serialize message field [angle_x]
    bufferOffset = _serializer.float32(obj.angle_x, buffer, bufferOffset);
    // Serialize message field [angle_y]
    bufferOffset = _serializer.float32(obj.angle_y, buffer, bufferOffset);
    // Serialize message field [angle_z]
    bufferOffset = _serializer.float32(obj.angle_z, buffer, bufferOffset);
    // Serialize message field [equ_a]
    bufferOffset = _serializer.float32(obj.equ_a, buffer, bufferOffset);
    // Serialize message field [equ_b]
    bufferOffset = _serializer.float32(obj.equ_b, buffer, bufferOffset);
    // Serialize message field [equ_c]
    bufferOffset = _serializer.float32(obj.equ_c, buffer, bufferOffset);
    // Serialize message field [equ_d]
    bufferOffset = _serializer.float32(obj.equ_d, buffer, bufferOffset);
    // Serialize message field [vec_x]
    bufferOffset = Vector.serialize(obj.vec_x, buffer, bufferOffset);
    // Serialize message field [vec_y]
    bufferOffset = Vector.serialize(obj.vec_y, buffer, bufferOffset);
    // Serialize message field [vec_z]
    bufferOffset = Vector.serialize(obj.vec_z, buffer, bufferOffset);
    // Serialize message field [mean_center]
    bufferOffset = Point.serialize(obj.mean_center, buffer, bufferOffset);
    // Serialize message field [median_center]
    bufferOffset = Point.serialize(obj.median_center, buffer, bufferOffset);
    // Serialize message field [size_center]
    bufferOffset = Point.serialize(obj.size_center, buffer, bufferOffset);
    // Serialize message field [octagon_points]
    // Serialize the length for message field [octagon_points]
    bufferOffset = _serializer.uint32(obj.octagon_points.length, buffer, bufferOffset);
    obj.octagon_points.forEach((val) => {
      bufferOffset = Point.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Plane
    let len;
    let data = new Plane(null);
    // Deserialize message field [frame_id]
    data.frame_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [width]
    data.width = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [height]
    data.height = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [angle_x]
    data.angle_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [angle_y]
    data.angle_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [angle_z]
    data.angle_z = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [equ_a]
    data.equ_a = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [equ_b]
    data.equ_b = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [equ_c]
    data.equ_c = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [equ_d]
    data.equ_d = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [vec_x]
    data.vec_x = Vector.deserialize(buffer, bufferOffset);
    // Deserialize message field [vec_y]
    data.vec_y = Vector.deserialize(buffer, bufferOffset);
    // Deserialize message field [vec_z]
    data.vec_z = Vector.deserialize(buffer, bufferOffset);
    // Deserialize message field [mean_center]
    data.mean_center = Point.deserialize(buffer, bufferOffset);
    // Deserialize message field [median_center]
    data.median_center = Point.deserialize(buffer, bufferOffset);
    // Deserialize message field [size_center]
    data.size_center = Point.deserialize(buffer, bufferOffset);
    // Deserialize message field [octagon_points]
    // Deserialize array length for message field [octagon_points]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.octagon_points = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.octagon_points[i] = Point.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.frame_id.length;
    length += 12 * object.octagon_points.length;
    return length + 116;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pcm_msgs/Plane';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e3d1fd5c2114696280ab516cc701695e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string frame_id
    float32 width
    float32 height
    float32 angle_x
    float32 angle_y
    float32 angle_z
    float32 equ_a
    float32 equ_b
    float32 equ_c
    float32 equ_d
    Vector vec_x
    Vector vec_y
    Vector vec_z
    Point mean_center
    Point median_center
    Point size_center
    Point[] octagon_points
    
    ================================================================================
    MSG: pcm_msgs/Vector
    float32 X
    float32 Y
    float32 Z
    
    ================================================================================
    MSG: pcm_msgs/Point
    float32 x
    float32 y
    float32 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Plane(null);
    if (msg.frame_id !== undefined) {
      resolved.frame_id = msg.frame_id;
    }
    else {
      resolved.frame_id = ''
    }

    if (msg.width !== undefined) {
      resolved.width = msg.width;
    }
    else {
      resolved.width = 0.0
    }

    if (msg.height !== undefined) {
      resolved.height = msg.height;
    }
    else {
      resolved.height = 0.0
    }

    if (msg.angle_x !== undefined) {
      resolved.angle_x = msg.angle_x;
    }
    else {
      resolved.angle_x = 0.0
    }

    if (msg.angle_y !== undefined) {
      resolved.angle_y = msg.angle_y;
    }
    else {
      resolved.angle_y = 0.0
    }

    if (msg.angle_z !== undefined) {
      resolved.angle_z = msg.angle_z;
    }
    else {
      resolved.angle_z = 0.0
    }

    if (msg.equ_a !== undefined) {
      resolved.equ_a = msg.equ_a;
    }
    else {
      resolved.equ_a = 0.0
    }

    if (msg.equ_b !== undefined) {
      resolved.equ_b = msg.equ_b;
    }
    else {
      resolved.equ_b = 0.0
    }

    if (msg.equ_c !== undefined) {
      resolved.equ_c = msg.equ_c;
    }
    else {
      resolved.equ_c = 0.0
    }

    if (msg.equ_d !== undefined) {
      resolved.equ_d = msg.equ_d;
    }
    else {
      resolved.equ_d = 0.0
    }

    if (msg.vec_x !== undefined) {
      resolved.vec_x = Vector.Resolve(msg.vec_x)
    }
    else {
      resolved.vec_x = new Vector()
    }

    if (msg.vec_y !== undefined) {
      resolved.vec_y = Vector.Resolve(msg.vec_y)
    }
    else {
      resolved.vec_y = new Vector()
    }

    if (msg.vec_z !== undefined) {
      resolved.vec_z = Vector.Resolve(msg.vec_z)
    }
    else {
      resolved.vec_z = new Vector()
    }

    if (msg.mean_center !== undefined) {
      resolved.mean_center = Point.Resolve(msg.mean_center)
    }
    else {
      resolved.mean_center = new Point()
    }

    if (msg.median_center !== undefined) {
      resolved.median_center = Point.Resolve(msg.median_center)
    }
    else {
      resolved.median_center = new Point()
    }

    if (msg.size_center !== undefined) {
      resolved.size_center = Point.Resolve(msg.size_center)
    }
    else {
      resolved.size_center = new Point()
    }

    if (msg.octagon_points !== undefined) {
      resolved.octagon_points = new Array(msg.octagon_points.length);
      for (let i = 0; i < resolved.octagon_points.length; ++i) {
        resolved.octagon_points[i] = Point.Resolve(msg.octagon_points[i]);
      }
    }
    else {
      resolved.octagon_points = []
    }

    return resolved;
    }
};

module.exports = Plane;
