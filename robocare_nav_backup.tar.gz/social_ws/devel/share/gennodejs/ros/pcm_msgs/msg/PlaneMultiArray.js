// Auto-generated. Do not edit!

// (in-package pcm_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Plane = require('./Plane.js');

//-----------------------------------------------------------

class PlaneMultiArray {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.plane = null;
    }
    else {
      if (initObj.hasOwnProperty('plane')) {
        this.plane = initObj.plane
      }
      else {
        this.plane = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PlaneMultiArray
    // Serialize message field [plane]
    // Serialize the length for message field [plane]
    bufferOffset = _serializer.uint32(obj.plane.length, buffer, bufferOffset);
    obj.plane.forEach((val) => {
      bufferOffset = Plane.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PlaneMultiArray
    let len;
    let data = new PlaneMultiArray(null);
    // Deserialize message field [plane]
    // Deserialize array length for message field [plane]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.plane = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.plane[i] = Plane.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.plane.forEach((val) => {
      length += Plane.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pcm_msgs/PlaneMultiArray';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1f8621a7a26b2313fa26c5cfe1df0f84';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Plane[] plane
    
    ================================================================================
    MSG: pcm_msgs/Plane
    string frame_id
    float32 width
    float32 height
    float32 angle_x
    float32 angle_y
    float32 angle_z
    float32 equ_a
    float32 equ_b
    float32 equ_c
    float32 equ_d
    Vector vec_x
    Vector vec_y
    Vector vec_z
    Point mean_center
    Point median_center
    Point size_center
    Point[] octagon_points
    
    ================================================================================
    MSG: pcm_msgs/Vector
    float32 X
    float32 Y
    float32 Z
    
    ================================================================================
    MSG: pcm_msgs/Point
    float32 x
    float32 y
    float32 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PlaneMultiArray(null);
    if (msg.plane !== undefined) {
      resolved.plane = new Array(msg.plane.length);
      for (let i = 0; i < resolved.plane.length; ++i) {
        resolved.plane[i] = Plane.Resolve(msg.plane[i]);
      }
    }
    else {
      resolved.plane = []
    }

    return resolved;
    }
};

module.exports = PlaneMultiArray;
