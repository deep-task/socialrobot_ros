
"use strict";

let RegisterInMap = require('./RegisterInMap.js')
let PcmLocalization = require('./PcmLocalization.js')

module.exports = {
  RegisterInMap: RegisterInMap,
  PcmLocalization: PcmLocalization,
};
