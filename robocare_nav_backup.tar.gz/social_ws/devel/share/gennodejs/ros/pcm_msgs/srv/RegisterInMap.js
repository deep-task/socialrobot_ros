// Auto-generated. Do not edit!

// (in-package pcm_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class RegisterInMapRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RegisterInMapRequest
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RegisterInMapRequest
    let len;
    let data = new RegisterInMapRequest(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'pcm_msgs/RegisterInMapRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd24b1b35259f10d6b0cfb668500c1f35';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 STATUS_SUCCESS = 1
    uint8 STATUS_NO_PLANE = 2
    uint8 STATUS_NO_MAP_NAME = 3
    uint8 STATUS_UNKNOWN_ERROR = 4
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RegisterInMapRequest(null);
    return resolved;
    }
};

// Constants for message
RegisterInMapRequest.Constants = {
  STATUS_SUCCESS: 1,
  STATUS_NO_PLANE: 2,
  STATUS_NO_MAP_NAME: 3,
  STATUS_UNKNOWN_ERROR: 4,
}

class RegisterInMapResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.result = null;
    }
    else {
      if (initObj.hasOwnProperty('result')) {
        this.result = initObj.result
      }
      else {
        this.result = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RegisterInMapResponse
    // Serialize message field [result]
    bufferOffset = _serializer.uint8(obj.result, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RegisterInMapResponse
    let len;
    let data = new RegisterInMapResponse(null);
    // Deserialize message field [result]
    data.result = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'pcm_msgs/RegisterInMapResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '25458147911545c320c4c0a299eff763';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 result
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RegisterInMapResponse(null);
    if (msg.result !== undefined) {
      resolved.result = msg.result;
    }
    else {
      resolved.result = 0
    }

    return resolved;
    }
};

module.exports = {
  Request: RegisterInMapRequest,
  Response: RegisterInMapResponse,
  md5sum() { return 'c59c403384a710cd0d351d99a2044970'; },
  datatype() { return 'pcm_msgs/RegisterInMap'; }
};
