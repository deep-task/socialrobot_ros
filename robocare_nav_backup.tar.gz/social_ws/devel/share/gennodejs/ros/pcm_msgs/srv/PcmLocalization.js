// Auto-generated. Do not edit!

// (in-package pcm_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class PcmLocalizationRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.pose_x = null;
      this.pose_y = null;
      this.angle = null;
    }
    else {
      if (initObj.hasOwnProperty('pose_x')) {
        this.pose_x = initObj.pose_x
      }
      else {
        this.pose_x = 0;
      }
      if (initObj.hasOwnProperty('pose_y')) {
        this.pose_y = initObj.pose_y
      }
      else {
        this.pose_y = 0;
      }
      if (initObj.hasOwnProperty('angle')) {
        this.angle = initObj.angle
      }
      else {
        this.angle = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PcmLocalizationRequest
    // Serialize message field [pose_x]
    bufferOffset = _serializer.int64(obj.pose_x, buffer, bufferOffset);
    // Serialize message field [pose_y]
    bufferOffset = _serializer.int64(obj.pose_y, buffer, bufferOffset);
    // Serialize message field [angle]
    bufferOffset = _serializer.int64(obj.angle, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PcmLocalizationRequest
    let len;
    let data = new PcmLocalizationRequest(null);
    // Deserialize message field [pose_x]
    data.pose_x = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [pose_y]
    data.pose_y = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [angle]
    data.angle = _deserializer.int64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 24;
  }

  static datatype() {
    // Returns string type for a service object
    return 'pcm_msgs/PcmLocalizationRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'bf6da249a9f0e1aa9e326bd9402e050a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int64 pose_x
    int64 pose_y
    int64 angle
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PcmLocalizationRequest(null);
    if (msg.pose_x !== undefined) {
      resolved.pose_x = msg.pose_x;
    }
    else {
      resolved.pose_x = 0
    }

    if (msg.pose_y !== undefined) {
      resolved.pose_y = msg.pose_y;
    }
    else {
      resolved.pose_y = 0
    }

    if (msg.angle !== undefined) {
      resolved.angle = msg.angle;
    }
    else {
      resolved.angle = 0
    }

    return resolved;
    }
};

class PcmLocalizationResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.pose_x = null;
      this.pose_y = null;
      this.angle = null;
    }
    else {
      if (initObj.hasOwnProperty('pose_x')) {
        this.pose_x = initObj.pose_x
      }
      else {
        this.pose_x = 0;
      }
      if (initObj.hasOwnProperty('pose_y')) {
        this.pose_y = initObj.pose_y
      }
      else {
        this.pose_y = 0;
      }
      if (initObj.hasOwnProperty('angle')) {
        this.angle = initObj.angle
      }
      else {
        this.angle = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PcmLocalizationResponse
    // Serialize message field [pose_x]
    bufferOffset = _serializer.int64(obj.pose_x, buffer, bufferOffset);
    // Serialize message field [pose_y]
    bufferOffset = _serializer.int64(obj.pose_y, buffer, bufferOffset);
    // Serialize message field [angle]
    bufferOffset = _serializer.float32(obj.angle, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PcmLocalizationResponse
    let len;
    let data = new PcmLocalizationResponse(null);
    // Deserialize message field [pose_x]
    data.pose_x = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [pose_y]
    data.pose_y = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [angle]
    data.angle = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 20;
  }

  static datatype() {
    // Returns string type for a service object
    return 'pcm_msgs/PcmLocalizationResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '799958773c6e4288cdc827c2beb97114';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int64 pose_x
    int64 pose_y
    float32 angle
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PcmLocalizationResponse(null);
    if (msg.pose_x !== undefined) {
      resolved.pose_x = msg.pose_x;
    }
    else {
      resolved.pose_x = 0
    }

    if (msg.pose_y !== undefined) {
      resolved.pose_y = msg.pose_y;
    }
    else {
      resolved.pose_y = 0
    }

    if (msg.angle !== undefined) {
      resolved.angle = msg.angle;
    }
    else {
      resolved.angle = 0.0
    }

    return resolved;
    }
};

module.exports = {
  Request: PcmLocalizationRequest,
  Response: PcmLocalizationResponse,
  md5sum() { return '027a830f4d8d0f3b88869ca0f6ba7551'; },
  datatype() { return 'pcm_msgs/PcmLocalization'; }
};
