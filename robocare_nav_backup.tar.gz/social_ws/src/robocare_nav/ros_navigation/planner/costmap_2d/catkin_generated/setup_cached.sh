#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/kkbaek/kkback_ws/ros_navigation_ws/src/navigation/costmap_2d/devel:$CMAKE_PREFIX_PATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/kkbaek/kkback_ws/ros_navigation_ws/src/navigation/costmap_2d/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/kkbaek/kkback_ws/ros_navigation_ws/src/navigation/costmap_2d:$ROS_PACKAGE_PATH"